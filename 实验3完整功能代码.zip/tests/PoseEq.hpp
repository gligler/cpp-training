#pragma once
#include "Executor.hpp"

namespace adas
{
    bool operator==(const Pose& lhs, const Pose& rhs);
}